#! /bin/bash
if [[ "$1" == "--help" ]]; then
	echo "Uso: $0 ORIGEN DESTINO"
	exit 0
fi
ORIGEN=$1
DESTINO=$2

if  [[ ! -d "$ORIGEN"  || ! -d "$DESTINO" ]]; then
	echo "Error: origen o destino inexistente"
	exit 1
fi


FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"
