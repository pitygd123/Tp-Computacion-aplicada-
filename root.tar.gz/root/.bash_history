history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ls
cd
ls
which nano
nano --version
apt update
sudo apt update
apt update
ping 8.8.8.8
cd /etc/network 
ls
cd /etc/network/interfaces 
cd /etc/network/interfaces.d
ls
ls
apt update
apt-get install openssh-server
ls /etc
cd /etc/shh
cd /etc/ssh
cd ..
pwd
ls
apt-get install openssh-server
ls
cd /etc/ssh
ls
cd /etc/ssh/ssh_config
nano ssh_config
sudo ssh_config
apt update
apt install openssh-server
ip a
ip a
ip route
cat /etc/resolv.conf
cat /etc/resolv.conf
cat /etc/default/keyboard

dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration     
 
 
 
 
 
 
 
 
clear
ping -c 4 8.8.8.8
ping -c 4 deb.debian.org
cat /etc/apt/sources.list
vi /etc/aot/sources.list

vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
shutdown -r
-c
vi /etc/ssh/sshd_config
grep -n "PermitRootLogin" /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
clear
vi /PermitRootLogin
clear
vi /etc/ssh/sshd_config
clear
vim /etc/ssh/sshd_config
clear
systemctl restart ssh
man ssh-keygen
ssh-keygen
cat /root/.ssh/authorized_keys
cd /root/.ssh/authorized_keys
cd /root/.ssh/
ls
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
ip a
clear
ip a
apt update
apt install apache2
apt install php7
apt install php libapache2-mod-php
apt install php7.3
apt install php7. 3
clear
php -v
sudo nano /root/index.php
sudo vim /root/index.php
dddw dsdwdwddww:d
cle
clear
cat /etc/index.php
sudo vim /root/index.php
clear
sudo vim /root/index.php
clear
apt install nano
clear
sudo nano /root/index.php
clear
clear
sudo cp /root/index.php /var/www/html/
sudo cp /root/logo.png /var/www/html/
sudo systemctl restart apache2
apt install mariadb-server
apt install php-mysql
clear
sudo mysql_secure_installation 
clear
sudo mysql
sudo apt update
sudo apt install mariadb-server -y
systemctl status mariadb
systemctl start mariadb
sudo systemctl status mariadb
sudo systemctl start mariadb
sudo systemctl enable mariadb
sudo mysql_secure_installation
ls -l /root/db.sql
sudo mysql < /root/db.sql
sudo mysql
find / -name"db.sql" 2>/dev/null
sudo mariadb-u root -p < ./db.sql
apt install mariadbclient
apt install mariadb-client
sudo mariadb-u root -p < ./db.sql
ip a
sudo nano /etc/network/interfaces
sudo reboot
ip addr show enp0s3
cat /etc/network/interfaces
sudo nano /etc/network/interfaces
ip addr show enp0s3
cat /etc/network/interfaces
sudo reboot
systemctl restar networking
systemctl restart networking
ip addr show enp0s3
ip route
sudo mkdir /www_dir
sudo cp /root/index.php /www_dir/
sudo touch /root/logo.png
sudo cp /root/logo.png /www_dir/
sudo nano /etc/apache2/sites-available/000-default.conf
clea
clear
sudo systemctl restart apache2
sudo blkid
clea
clear
sudo nano /etc/fstab
clear

sudo blkid
clear
sudo mkdir /backup_dir
sudo mount /dev/sdb2 /backup/_dir
sudo mount /dev/sdb2 /backup_dir
clear
lsblk -0 NAME,SIZE,FSTYPE,MOUNTPOINT
lsblk -O NAME,SIZE,FSTYPE,MOUNTPOINT
lsbldk
lsblk
clear
sudo blkid
sudo nano /etc/fstab
sudo nano /etc/fstab
sudo mount /dev/sdc2 /backup_dir
mount -o remount,rw /
mount | grep "/"
nano /etc/fstab
clear
find / -name "logo.png: 2>/dev/null
find /root -name "index.php"
ip a
clear

ip a
systemctl status ssh
ss -tlnp | grep:22
ss -tlnp | grep :22
systemctl start ssh
systemctl status ssh
ss -tnlp | grep ':22'
ssh localhost
clear
ip a
sudo systemctl status ssh
sudo ss -tlnp | grep :22
ip a
vim /etc/ssh/sshd-config
clear
vim /etc/ssh/sshd_config
clear
vim /etc/ssh/sshd_config
clear
cat /etc/ssh/sshd_config
clear
vim /etc/ssh/sshd_config
clear
vim /etc/ssh/sshd_config
clear
reboot
vim /etc/ssh/sshd_config
clear
ip a
reboot
ls
cat /root/index.php
tar -xvzf Material_Adicional_TPVMCA.tar.gz
vim /etc/ssh/sshd_config
clear
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ls -l /var/www/html
sudo mysql -u root < /root/db.sql
 mysql -u root < /root/db.sql
mariadb < /root/db.sql
ls /root/
ls /root/Material_Adicional_TPVMCA
mysql -u <  /root/Material_Adicional_TPVMCA/db.sql
mysql -u root <  /root/Material_Adicional_TPVMCA/db.sql
mariadb
ls /root/Material_Adicional_TPVMCA
mkdir -p /root/.ssh
cat /root/Material_Adicional_TPVMCA/clave_publica.pub > /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
vim /etc/ssh/sshd_config
clear
nano /etc/ssh/sshd_config
clear
ls -l /root/.ssh
'chmod 600 /root/.ssh/authorized_keys
ls- ld /root/.ssh
chmod 700 /root/.ssh
ip a
cat /etc/network/interfaces
nano  /etc/network/interfaces
ip a
systemctl status ssh
ss -tnlp 
ssh localhost
ufw status
hostname -i
hostname -I
iptables -L -n
ip a
reboot
hostname -I
cd /etc/network
nano interfaces
clear
grep Port /etc/ssh/sshd_config
grep ListenAddress /etc/ssh/sshd_config
grep AddressFamily
dpkg-reconfigure keyboard-configuration
clear
reboot
tar -czvf root.tar.gz /root
dhclient enp0s3
hostname -i
ip link show enp0s3
ip link set enp0s3 up
dhclient enp0s3
hostname -i
ip link set enp0s3
ip link set enp0s3 up
dhclient enp0s3
hostname -I
hostname -i
dhclient -v enp0s3
ip addr show enp0s3
ip addr add 192.168.1.50/24 dev enp0s3
ip route add default via 192.168.1.1
ping 192.168.1.1
systemctl status ssh
ss -tlnp | grep 22
cat /root/.ssh/authorized_keys
sshd -t | grep loglevel
tail -f /var/log/auth.log
journalctl -u ssh -n 20
car /etc/ssh/sshd/sshd_config | grep -e "Port|ListenAddress|AddressFamily"
cat /etc/ssh/sshd/sshd_config | grep -e "Port|ListenAddress|AddressFamily"
find / -name "sshd_config" 2>/dev/null
cat /etc/ssh/sshd_config | grep -e "Port|ListenAddress|AddressFamily|PermitRootLogin|PubkeyAuthentication|PasswordAuthentication"
cat /etc/ssh/sshd_config
head -50 /etc/ssh/sshd_config
ls /etc/ssh/sshd_config.d/*.config.d/
ls /etc/ssh/sshd_config.d/.config.d/
cat/etc/ssh/sshd_config.d/*.conf
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
tcpdump -i any port 22
apt install tcpdump -y
tcp -i any port 22
tcpdump -i any port 22
/usr/sbin/tcdump -i any port 22
which tcpdump
lsblk
reboot
