<?php
echo "<h1>Servidor Apache con PHP funcionando correctamente</h1>";
echo"<img src ='logo.png' alt='logo'>";
?>
